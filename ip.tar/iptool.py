import os
import re
import subprocess
import shutil
import argparse
import ssl
import json
import platform

PYTHON_VERSION = int((platform.python_version())[0])

if PYTHON_VERSION == 2:
    import urllib
    import lib.v2.yaml as yaml
else:
    import urllib.request
    import lib.v3.yaml as yaml


class InvalidNetworksInformationFile(Exception):
    pass


class AlreadyAddedError(Exception):
    pass


class IPInformationNotFound(Exception):
    pass


class NetworkInterfaceConfigNotFound(Exception):
    pass


class NetworkInterfaceUndefined(Exception):
    pass


class OSNetworkManagementTypeNotSupported(Exception):

    def __init__(self, *args, **kwargs):
        Exception.__init__(self, "OS network management type not supported.", *args, **kwargs)


class NetworkAPIFactory:

    @staticmethod
    def getNetworkAPIInstance():
        for api in [NetworkScriptsTypeNetworkAPI, NetworkManagerTypeNetworkAPI,
                    NetPlanTypeNetworkAPI, InterfacesFileTypeNetworkAPI]:
            if api.areYouSupported():
                return api()
        raise OSNetworkManagementTypeNotSupported


class Util:

    @classmethod
    def runCommand(cls, command):
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            out, errors = process.communicate()
        except subprocess.TimeoutExpired:
            process.kill()
            out, errors = process.communicate()
        finally:
            if out is not None:
                out = out.decode()
            else:
                out = ""

            if errors is not None:
                errors = errors.decode()
            else:
                errors = ""

            return {"out": out, "errors": errors}


class NetworkAPI:

    INTERFACE_IP_REGEXP = re.compile(r"^\d+\:\s(\S+)\s+inet\s+(([0-9]{1,3}[\.]){3}[0-9]{1,3})")
    IP_REGEXP = re.compile(r"(([0-9]{1,3}[\.]){3}[0-9]{1,3})")

    def __init__(self):
        self._context = ssl._create_unverified_context()
        self._PREFIX_DATA_URL = "https://cp.deltahost.com/files/prefixes.json"

        if PYTHON_VERSION == 2:
            response = urllib.urlopen(self._PREFIX_DATA_URL, context=self._context)
        else:
            response = urllib.request.urlopen(self._PREFIX_DATA_URL, context=self._context)

        result = response.read().decode()

        self._NETWORKS = {"127.0.0.0/8": "127.0.0.1"}
        try:
            resultDict = json.loads(result)
            for entry in resultDict["prefixes"]:
                self._NETWORKS["{}/{}".format(entry["network"], entry["mask"])] = "{}".format(entry["gateway"])
        except (ValueError, AttributeError, TypeError):
            raise InvalidNetworksInformationFile(str(result))

        self._template = "IP:{IP}\nNETWORK:{NETWORK}\nLENGTH:{LENGTH}\nMASK:{MASK}\nGATEWAY:{GATEWAY}"
        self._networkInterface = None
        self._addresses = []
        self._result = []

    def clear(self):
        self._addresses = []
        self._result = []

    def checkIP(self, ip):
        if not self.isAlreadyAdded(ip):
            self._configByTemplate(ip)
        else:
            raise AlreadyAddedError

    def addIP(self, ip):
        if not self.isAlreadyAdded(ip):
            self._addresses.append(ip)
            result = self._configByTemplate(ip)
            if result != "":
                self._result.append(result)
        else:
            raise AlreadyAddedError

    def _configByTemplate(self, ip):
        networkParams = self._getNetworkParamsByIPAddress(ip)
        return self._template.format(
            IP=networkParams["IP"],
            NETWORK=networkParams["NETWORK"],
            LENGTH=networkParams["LENGTH"],
            MASK=networkParams["MASK"],
            GATEWAY=networkParams["GATEWAY"]
        )

    def isAlreadyAdded(self, ip):
        try:
            self._addresses.index(ip)
            return True
        except ValueError:
            return False

    def _getNetworkParamsByIPAddress(self, ip):
        net = self.__getNetworkByIP(ip, self._NETWORKS)
        if net:
            netAddress, netLength = re.split('/', net)
            params = {
                "IP": ip,
                "NETWORK": netAddress,
                "LENGTH": netLength,
                "MASK": str(self.__convertLengthToMask(netLength)),
                "GATEWAY": self._NETWORKS[net]
            }
            return params
        else:
            raise IPInformationNotFound

    @classmethod
    def parseIPToolOutput(cls, output):
        parsed = []
        if type(output) != str:
            return parsed
        else:
            for i in output.split("\n"):
                result = cls.INTERFACE_IP_REGEXP.search(i)
                if result is not None:
                    parsed.append({"interface": result.group(1), "ip": result.group(2)})
            return parsed

    @classmethod
    def __getNetworkByIP(cls, ip, networks_list):
        ip_n = cls.__convertIPToNumber(ip)
        for net in networks_list.keys():
            netAddress, netLength = net.split("/")
            mask = 0xFFFFFFFF - ((1 << (32 - int(netLength))) - 1)
            net_n = cls.__convertIPToNumber(netAddress)
            ip_n_temp = ip_n & mask
            if ip_n_temp == net_n:
                return net
        return 0

    @classmethod
    def __convertIPToNumber(cls, ip):
        a, b, c, d = ip.split(".")
        number = (int(a) << 24) + (int(b) << 16) + (int(c) << 8) + int(d)
        return number

    @classmethod
    def __convertLengthToMask(cls, netLength):
        mask = 0xFFFFFFFF - ((1 << (32 - int(netLength))) - 1)
        mask_human = str(((mask & 0xFF000000) >> 24)) + "." + str(((mask & 0x00FF0000) >> 16)) + "." + \
                     str(((mask & 0x0000FF00) >> 8)) + "." + str((mask & 0x000000FF))
        return mask_human

    @classmethod
    def checkIPSyntax(cls, ip):
        if cls.IP_REGEXP.match(ip):
            return True
        else:
            return False

    def setNetworkInterface(self, networkInterfaceName):
        self._networkInterface = networkInterfaceName
        self._result = []
        if len(self._addresses) > 0:
            addresses = []
            addresses += self._addresses
            self._addresses = []
            for i in addresses:
                self.addIP(i)

    def getNetworkInterface(self):
        return self._networkInterface

    def saveConfig(self):
        if self._networkInterface is None:
            raise NetworkInterfaceUndefined("Network interface undefined. Save config operation failed.")

    def getResult(self):
        return self._result

    def getIPListFromIfCfg(self, data):
        return []

    @classmethod
    def areYouSupported(cls):
        return True


class NetworkScriptsTypeNetworkAPI(NetworkAPI):

    IP_COMMAND = "ip -o a"
    IFCFG_FILE_PREFIX = "ifcfg-"
    IFCFG_FILE_SUFFIX = re.compile(r'\d+$')
    IFCFG_FILE_SUFFIX_SPLITTER = re.compile(r'([a-z\d]+)\:(\d+)$')
    IPADDR_IFCFG_REGEXP = re.compile(r'IPADDR=\"?(([0-9]{1,3}[\.]){3}[0-9]{1,3})\"?')

    def __init__(self, *args, **kwargs):
        NetworkAPI.__init__(self, *args, **kwargs)
        self._template = "DEVICE=\"{DEVICE}:{NUMBER}\"\nBOOTPROTO=none\nNM_CONTROLLED=\"no\"" + \
                         "\nONBOOT=\"yes\"\nIPADDR={IP}\nNETMASK={MASK}"
        self.ifCfgDir = "/etc/sysconfig/network-scripts"
        self._number = 1
        self._lastConfigNumber = -1
        self._numbers = []

    def clear(self):
        self._numbers = []
        self._number = 1
        self._lastConfigNumber = -1
        NetworkAPI.clear(self)

    def setNetworkInterface(self, networkInterfaceName):
        self._numbers = []
        self._number = 1
        self._lastConfigNumber = -1
        NetworkAPI.setNetworkInterface(self, networkInterfaceName)

    def getIPListFromIfCfg(self, data):
        ipList = []
        for i in data.split("\n"):
            result = self.IPADDR_IFCFG_REGEXP.search(i)
            if result is not None and result.group(1) != "":
                ipList.append({"number": 0, "ip": result.group(1).strip()})
        return ipList

    def _configByTemplate(self, ip):
        numbers = []
        networkParams = self._getNetworkParamsByIPAddress(ip)

        if self._lastConfigNumber == -1:
            # Find IP in configs
            if re.search(r"\/$", self.ifCfgDir) is None:
                ifCfgDir = self.ifCfgDir + "/"
            else:
                ifCfgDir = self.ifCfgDir

            if os.path.exists(ifCfgDir):
                for entry in os.listdir(ifCfgDir):
                    FILENAME = "{}{}".format(ifCfgDir, entry)
                    if os.path.isfile(FILENAME):
                        if entry.find(self.IFCFG_FILE_PREFIX) != -1:
                            result = self.IFCFG_FILE_SUFFIX_SPLITTER.search(entry)
                            if result is not None and result.group(2) != "":
                                if result.group(1) == self._networkInterface:
                                    numbers.append(int(result.group(2)))
            if len(numbers) > 0:
                numbers.sort()
                self._lastConfigNumber = numbers[len(numbers) - 1]
            else:
                self._lastConfigNumber = 0
            self._number = self._lastConfigNumber + 1
        else:
            self._number += 1

        self._numbers.append(self._number)

        return self._template.format(
            DEVICE=self._networkInterface,
            IP=networkParams["IP"],
            MASK=networkParams["MASK"],
            NUMBER=self._number
        )

    def isAlreadyAdded(self, ip):
        if not NetworkAPI.isAlreadyAdded(self, ip):
            found = 0

            # Find IP on interfaces
            result = Util.runCommand(self.IP_COMMAND)
            result["out"] = str(result["out"])
            for i in self.parseIPToolOutput(result["out"]):
                if i["ip"] == ip:
                    found = 1
                    break

            # Find IP in configs
            if re.search(r"\/$", self.ifCfgDir) is None:
                ifCfgDir = self.ifCfgDir + "/"
            else:
                ifCfgDir = self.ifCfgDir

            if os.path.exists(ifCfgDir):
                for entry in os.listdir(ifCfgDir):
                    FILENAME = "{}{}".format(ifCfgDir, entry)
                    if os.path.isfile(FILENAME):
                        if (entry.find(self.IFCFG_FILE_PREFIX) != -1 and
                                self.IFCFG_FILE_SUFFIX.search(entry) is not None):
                            try:
                                f = open(FILENAME, "r")
                                data = f.read()
                                f.close()
                            except OSError:
                                continue

                            for i in self.getIPListFromIfCfg(data):
                                if i["ip"] == ip:
                                    found = 1
                                    break

            if found:
                return True
            else:
                return False
        else:
            return True

    def getIfCfgDir(self):
        return self.ifCfgDir

    def setIfCfgDir(self, name):
        self.ifCfgDir = name

    def saveConfig(self):
        NetworkAPI.saveConfig(self)
        # Find IP in configs
        if re.search(r"\/$", self.ifCfgDir) is None:
            ifCfgDir = self.ifCfgDir + "/"
        else:
            ifCfgDir = self.ifCfgDir

        if os.path.exists(ifCfgDir):
            for i in range(0, len(self._result)):
                filename = "{}{}{}:{}".format(ifCfgDir, self.IFCFG_FILE_PREFIX,
                                              self._networkInterface, self._numbers[i])
                # Generate interface alias files
                f = open(filename, "w")
                data = (self.getResult())[i]
                f.write(data)
                f.close()

    @classmethod
    def areYouSupported(cls):
        if os.path.exists("/etc/sysconfig/network-scripts") and os.path.exists("/etc/init.d/network"):
            return True
        else:
            return False


class NetworkManagerTypeNetworkAPI(NetworkScriptsTypeNetworkAPI):

    IFCFG_FILE_SUFFIX = re.compile(r'[a-z]\d+$')
    IPADDR_IFCFG_REGEXP = re.compile(r'IPADDR(\d*)=\"?(([0-9]{1,3}[\.]){3}[0-9]{1,3})\"?')

    def __init__(self, *args, **kwargs):
        NetworkScriptsTypeNetworkAPI.__init__(self, *args, **kwargs)
        self._template = "IPADDR{NUMBER}={IP}\nPREFIX{NUMBER}={LENGTH}\n"

    def getIPListFromIfCfg(self, data):
        ipList = []
        for i in data.split("\n"):
            result = self.IPADDR_IFCFG_REGEXP.search(i)
            number = 0
            if result is not None and result.group(2) != "":
                if result.group(1) != "":
                    number = int(result.group(1))
                ipList.append({"number": number, "ip": result.group(2).strip()})
        return ipList

    def _configByTemplate(self, ip):
        numbers = []

        if self._lastConfigNumber == -1:
            # Find IP in configs
            if re.search(r"\/$", self.ifCfgDir) is None:
                ifCfgDir = self.ifCfgDir + "/"
            else:
                ifCfgDir = self.ifCfgDir

            if os.path.exists(ifCfgDir):
                for entry in os.listdir(ifCfgDir):
                    FILENAME = "{}{}".format(ifCfgDir, entry)
                    if os.path.isfile(FILENAME):
                        if (entry.find(self.IFCFG_FILE_PREFIX) != -1 and
                                self.IFCFG_FILE_SUFFIX.search(entry) is not None):
                            try:
                                f = open(FILENAME, "r")
                                data = f.read()
                                f.close()
                            except OSError:
                                continue

                            for i in self.getIPListFromIfCfg(data):
                                numbers.append(i["number"])
            if len(numbers) > 0:
                numbers.sort()
                self._lastConfigNumber = numbers[len(numbers) - 1]
            else:
                self._lastConfigNumber = 0
            self._number = self._lastConfigNumber + 1
        else:
            self._number += 1

        networkParams = self._getNetworkParamsByIPAddress(ip)
        return self._template.format(
            IP=networkParams["IP"],
            LENGTH=networkParams["LENGTH"],
            NUMBER=self._number
        )

    def saveConfig(self):
        if self._networkInterface is None:
            raise NetworkInterfaceUndefined("Network interface undefined. Save config operation failed.")

        # Find IP in configs
        if re.search(r"\/$", self.ifCfgDir) is None:
            ifCfgDir = self.ifCfgDir + "/"
        else:
            ifCfgDir = self.ifCfgDir

        if os.path.exists(ifCfgDir):
            FILENAME = "{}{}{}".format(ifCfgDir, self.IFCFG_FILE_PREFIX, self._networkInterface)
            if os.path.isfile(FILENAME):
                # Backup exists config
                shutil.copy(FILENAME, FILENAME + ".bak")
                # Update current config
                f = open(FILENAME, "a+")
                data = "\n"
                for i in self.getResult():
                    data += i
                f.write(data)
                f.close()
            else:
                raise NetworkInterfaceConfigNotFound(
                    "Config not found for interface '{}'. Save config operation failed.".format(self._networkInterface))

    @classmethod
    def areYouSupported(cls):
        if os.path.exists("/etc/sysconfig/network-scripts") and not os.path.exists("/etc/init.d/network"):
            return True
        else:
            return False


class NetPlanTypeNetworkAPI(NetworkAPI):

    IP_COMMAND = "ip -o a"
    IFCFG_FILE_SUFFIX = re.compile(r'\.yaml$')
    IPADDR_IFCFG_REGEXP = re.compile(r'\"?(([0-9]{1,3}[\.]){3}[0-9]{1,3})\"?')

    def __init__(self, *args, **kwargs):
        NetworkAPI.__init__(self, *args, **kwargs)
        self._template = "{IP}/{LENGTH}"
        self.ifCfgDir = "/etc/netplan"

    def isAlreadyAdded(self, ip):
        if not NetworkAPI.isAlreadyAdded(self, ip):
            found = 0

            # Find IP on interfaces
            result = Util.runCommand(self.IP_COMMAND)
            result["out"] = str(result["out"])
            for i in self.parseIPToolOutput(result["out"]):
                if i["ip"] == ip:
                    found = 1
                    break

            # Find IP in configs
            if re.search(r"\/$", self.ifCfgDir) is None:
                ifCfgDir = self.ifCfgDir + "/"
            else:
                ifCfgDir = self.ifCfgDir

            if os.path.exists(ifCfgDir):
                for entry in os.listdir(ifCfgDir):
                    FILENAME = "{}{}".format(ifCfgDir, entry)
                    if os.path.isfile(FILENAME):
                        if self.IFCFG_FILE_SUFFIX.search(entry) is not None:
                            try:
                                f = open(FILENAME, "r")
                                data = f.read()
                                f.close()
                            except OSError:
                                continue

                            for i in self.getIPListFromIfCfg(data):
                                if i["ip"] == ip:
                                    found = 1
                                    break

            if found:
                return True
            else:
                return False
        else:
            return True

    def getIPListFromIfCfg(self, data):
        try:
            netPlan = yaml.load(data, Loader=yaml.FullLoader)
        except AttributeError:
            netPlan = yaml.load(data)

        try:
            ethernetList = netPlan["network"]["ethernets"]
        except KeyError:
            return []

        ipList = []
        for interface, interfaceData in ethernetList.items():
            try:
                for address in interfaceData["addresses"]:
                    result = self.IPADDR_IFCFG_REGEXP.search(address)
                    if result is not None and result.group(1) != "":
                        ipList.append({"number": 0, "ip": result.group(1).strip()})
            except KeyError:
                continue

        return ipList

    def saveConfig(self):
        NetworkAPI.saveConfig(self)
        # Find IP in configs
        if re.search(r"\/$", self.ifCfgDir) is None:
            ifCfgDir = self.ifCfgDir + "/"
        else:
            ifCfgDir = self.ifCfgDir
        # Find config for current interface
        interfaceConfigPath = None
        interfaceConfigData = None
        if os.path.exists(ifCfgDir):
            for entry in os.listdir(ifCfgDir):
                FILENAME = "{}{}".format(ifCfgDir, entry)
                if os.path.isfile(FILENAME):
                    if self.IFCFG_FILE_SUFFIX.search(entry) is not None:
                        try:
                            f = open(FILENAME, "r")
                            data = f.read()
                            f.close()
                        except OSError:
                            continue

                        try:
                            netPlan = yaml.load(data, Loader=yaml.FullLoader)
                        except AttributeError:
                            netPlan = yaml.load(data)

                        try:
                            interface = netPlan["network"]["ethernets"][self._networkInterface]["addresses"]
                            interfaceConfigPath = FILENAME
                            interfaceConfigData = netPlan
                            break
                        except KeyError:
                            continue

        if interfaceConfigPath is None or interfaceConfigData is None:
            raise NetworkInterfaceConfigNotFound(
                "Config not found for interface '{}'. Save config operation failed.".format(self._networkInterface))
        else:
            # Backup exists config
            shutil.copy(interfaceConfigPath, interfaceConfigPath + ".bak")
            # Update current config
            for ip in self._result:
                interfaceConfigData["network"]["ethernets"][self._networkInterface]["addresses"].append(ip)

            f = open(interfaceConfigPath, 'w+')
            f.write(yaml.dump(interfaceConfigData))
            f.close()

    @classmethod
    def areYouSupported(cls):
        if os.path.exists("/etc/netplan") and len(os.listdir("/etc/netplan")) > 0:
            return True
        else:
            return False

    def getIfCfgDir(self):
        return self.ifCfgDir

    def setIfCfgDir(self, name):
        self.ifCfgDir = name


class InterfacesFileTypeNetworkAPI(NetworkManagerTypeNetworkAPI):

    IFCFG_FILE_PREFIX = "interfaces"
    IFCFG_FILE_SUFFIX = re.compile(r'interfaces')
    IFCFG_FILE = "interfaces"
    IFACE_NUMBER_REGEXP = re.compile(r'\:(\d+)\s+')
    IPADDR_IFCFG_REGEXP = re.compile(r'address\s\"?(([0-9]{1,3}[\.]){3}[0-9]{1,3})\"?')

    def __init__(self, *args, **kwargs):
        NetworkManagerTypeNetworkAPI.__init__(self, *args, **kwargs)
        self._template = "auto {DEVICE}:{NUMBER}\niface {DEVICE}:{NUMBER} inet static\naddress {IP}\nnetmask {MASK}\n\n"
        self.ifCfgDir = "/etc/network"

    def getIPListFromIfCfg(self, data):
        if self._networkInterface is None:
            raise NetworkInterfaceUndefined

        ipList = []
        number = 0
        for i in data.split("\n"):
            ip = self.IPADDR_IFCFG_REGEXP.search(i)
            if ip is not None and ip.group(1) != "":
                ipList.append({"ip": ip.group(1).strip()})
            if i.find("iface {}:".format(self._networkInterface)) == 0:
                found = self.IFACE_NUMBER_REGEXP.search(i)
                if found is not None and found.group(1) != "":
                    if int(found.group(1)) > number:
                        number = int(found.group(1))

        for j in ipList:
            j["number"] = number

        return ipList

    def _configByTemplate(self, ip):
        numbers = []

        if self._lastConfigNumber == -1:
            # Find IP in configs
            if re.search(r"\/$", self.ifCfgDir) is None:
                ifCfgDir = self.ifCfgDir + "/"
            else:
                ifCfgDir = self.ifCfgDir

            if os.path.exists(ifCfgDir):
                for entry in os.listdir(ifCfgDir):
                    FILENAME = "{}{}".format(ifCfgDir, entry)
                    if os.path.isfile(FILENAME):
                        if entry.find(self.IFCFG_FILE) != -1:
                            try:
                                f = open(FILENAME, "r")
                                data = f.read()
                                f.close()
                            except OSError:
                                continue

                            for i in self.getIPListFromIfCfg(data):
                                numbers.append(i["number"])
            if len(numbers) > 0:
                numbers.sort()
                self._lastConfigNumber = numbers[len(numbers) - 1]
            else:
                self._lastConfigNumber = 0
            self._number = self._lastConfigNumber + 1
        else:
            self._number += 1

        networkParams = self._getNetworkParamsByIPAddress(ip)
        return self._template.format(
            IP=networkParams["IP"],
            LENGTH=networkParams["LENGTH"],
            NUMBER=self._number,
            DEVICE=self._networkInterface,
            MASK=networkParams["MASK"]
        )

    def saveConfig(self):
        if self._networkInterface is None:
            raise NetworkInterfaceUndefined("Network interface undefined. Save config operation failed.")

        # Find IP in configs
        if re.search(r"\/$", self.ifCfgDir) is None:
            ifCfgDir = self.ifCfgDir + "/"
        else:
            ifCfgDir = self.ifCfgDir

        if os.path.exists(ifCfgDir):
            FILENAME = "{}{}".format(ifCfgDir, self.IFCFG_FILE)
            if os.path.isfile(FILENAME):
                # Backup exists config
                shutil.copy(FILENAME, FILENAME + ".bak")
                # Update current config
                f = open(FILENAME, "a+")
                data = "\n"
                for i in self.getResult():
                    data += i
                f.write(data)
                f.close()
            else:
                raise NetworkInterfaceConfigNotFound(
                    "Config not found for interface '{}'. Save config operation failed.".format(self._networkInterface))

    @classmethod
    def areYouSupported(cls):
        if os.path.exists("/etc/network/interfaces") and os.path.exists("/etc/init.d/networking"):
            return True
        else:
            return False


class Application:
    FILENAME_PARAM_HELP = "IP list file"
    ACTION_PARAM_CHECK = "check"
    ACTION_PARAM_ADD = "add"
    ACTION_PARAM_HELP = "add | check"
    INTERFACE_PARAM_HELP = "Network interface name like 'eth0','ens0'..."

    def __init__(self, networkApiObject):
        self.parser = argparse.ArgumentParser()
        self.networkAPI = networkApiObject
        self._log = []

    def run(self):
        self.parser = argparse.ArgumentParser()
        self.parser.add_argument("action", nargs="+", help=self.ACTION_PARAM_HELP)
        self.parser.add_argument("filename", nargs="+", help=self.FILENAME_PARAM_HELP)
        self.parser.add_argument("interface", nargs="+", help=self.INTERFACE_PARAM_HELP)
        args = self.parser.parse_args()
        actionArgsLength = len(args.action)
        fileNameArgsLength = len(args.filename)
        interfaceArgsLength = len(args.interface)
        if actionArgsLength == 0 or actionArgsLength > 1:
            self.parser.print_help()
        elif interfaceArgsLength == 0 or interfaceArgsLength > 1:
            self.parser.print_help()
        elif fileNameArgsLength == 0 or fileNameArgsLength > 1:
            self.parser.print_help()
        else:
            self.networkAPI.setNetworkInterface(args.interface[0])
            if args.action[0] == self.ACTION_PARAM_ADD or args.action[0] == self.ACTION_PARAM_CHECK:
                ips = self.getIPsFromFile(args.filename[0])
                self._do(ips, args.action[0])
            else:
                self.parser.print_help()

    def add(self, ips):
        self._do(ips, self.ACTION_PARAM_ADD)

    def check(self, ips):
        self._do(ips, self.ACTION_PARAM_CHECK)

    def _do(self, ips, action):
        self.networkAPI.clear()
        for ip in ips:
            try:
                if action == self.ACTION_PARAM_CHECK:
                    self.networkAPI.checkIP(ip)
                    self._log.append("IP '{}' checked".format(ip))
                elif action == self.ACTION_PARAM_ADD:
                    self.networkAPI.addIP(ip)
                    self._log.append("IP '{}' added to config".format(ip))
            except AlreadyAddedError:
                self._log.append("IP '{}' already added - skipped".format(ip))
            except IPInformationNotFound:
                self._log.append("IP '{}' network information not found - skipped".format(ip))
            except Exception as e:
                self._log.append("Error add ip '{}': {}".format(ip, e))

        if action == self.ACTION_PARAM_ADD:
            try:
                self.networkAPI.saveConfig()
                self._log.append("----------------------------------------------------------------------------------")
                self._log.append("Network config generated successfully to: {}".format(self.networkAPI.getIfCfgDir()))
                self._log.append("Please restart network to apply network settings")
            except Exception as e:
                self._log.append(str(e))

    def getIPsFromFile(self, fileName):
        f = open(fileName, "r")
        data = f.read()
        f.close()

        ipList = []
        for i in data.split("\n"):
            ip = i.strip()
            if ip != "":
                if self.networkAPI.checkIPSyntax(ip):
                    ipList.append(ip)
                else:
                    self._log.append("Entry '{}' has invalid IP syntax - skipped".format(ip))

        return ipList

    def getLog(self):
        return "\n".join(self._log)


if __name__ == "__main__":
    try:
        networkAPI = NetworkAPIFactory.getNetworkAPIInstance()
    except OSNetworkManagementTypeNotSupported as e:
        print(e)
        exit(1)

    app = Application(networkAPI)
    app.run()
    print(app.getLog())
